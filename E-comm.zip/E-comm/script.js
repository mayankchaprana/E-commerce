let cartItems = [];
let totalPrice = 0;

function addToCart(product) {
  cartItems.push(product);
  totalPrice += getProductPrice(product);
  updateCart();
}

function getProductPrice(product) {
  // Implement your logic to get the price of the product
  // This is just a placeholder
  if (product === 'Product 1') {
    return 19.99;
  } else if (product === 'Product 2') {
    return 24.99;
  }
}

function updateCart() {
  const cartItemsElement = document.getElementById('cart-items');
  const totalElement = document.getElementById('total-price');
  
  cartItemsElement.innerHTML = '';
  
  cartItems.forEach(item => {
    const cartItem = document.createElement('p');
    cartItem.textContent = item;
    cartItemsElement.appendChild(cartItem);
  });
  
  totalElement.textContent = 'Total: $' + totalPrice.toFixed(2);
  
  document.getElementById('cart').style.display = 'block';
}

function checkout() {
  // Implement your logic for the checkout process
  // This is just a placeholder
  alert('Thank you for your purchase!');
  cartItems = [];
  totalPrice = 0;
  updateCart();
}
